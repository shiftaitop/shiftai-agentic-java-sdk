package in.theshiftai.sdk.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.UUID;

/**
 * Request body for submitting feedback on a BOT message.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeedbackSubmissionRequest {
    private UUID messageId;
    private String feedbackTitle;
    private String feedback;
    private Boolean liked;
    private Boolean disliked;
    private Boolean regeneration;

    public FeedbackSubmissionRequest() {}

    // Getters and setters
    public UUID getMessageId() { return messageId; }
    public void setMessageId(UUID messageId) { this.messageId = messageId; }

    public String getFeedbackTitle() { return feedbackTitle; }
    public void setFeedbackTitle(String feedbackTitle) { this.feedbackTitle = feedbackTitle; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public Boolean getLiked() { return liked; }
    public void setLiked(Boolean liked) { this.liked = liked; }

    public Boolean getDisliked() { return disliked; }
    public void setDisliked(Boolean disliked) { this.disliked = disliked; }

    public Boolean getRegeneration() { return regeneration; }
    public void setRegeneration(Boolean regeneration) { this.regeneration = regeneration; }
}
